<footer class="row">
	<div class="footer_upper">
		<div class="container">
			<div class="footer_span">
				<h1>Address</h1>
				<p>Mayo Surgical, LLC<br>
				600 Chastain Road, Suite 200<br>
				Kennesaw, GA 30144<br>
				Phone: 1-866-411-2525<br>
				Fax: 1-866-865-8691</p>
			</div>
			<div class="footer_span">
				<h1>Quieck Links</h1>
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">About</a></li>
					<li><a href="#">Services</a></li>
				</ul>
			</div>
			<div class="footer_span">
				<h1>Legal</h1>
				<ul>
					<li><a href="#">FAQ</a></li>
					<li><a href="#">Terms</a></li>
					<li><a href="#">Contact us</a></li>
				</ul>
			</div>
			<div class="footer_social">
				<h1>Follow us</h1>
				<ul>
					<li class="social_facebook"><a href="#">Facebook</a></li>
					<li class="social_twitter"><a href="#">Twitter</a></li>
					<li class="social_linkedin"><a href="#">Linkedin</a></li>
				<ul>
			</div>
		</div>
	</div>
	<div class="footer_lower">
		<div class="container">
			<p>&copy; copyright 20104</p>
			<span class="scroll_top">
				<a href="#">Top</a>
			</span>
		</div>
	</div>
</footer>
</body>
</html>	
