<?php

$get_header = $_SERVER['DOCUMENT_ROOT']."/mayo/header.php";

$get_footer = $_SERVER['DOCUMENT_ROOT']."/mayo/footer.php";

$stylesheet = $_SERVER['DOCUMENT_ROOT']."/mayo/mayo-admin/users/style.css";

$mediacss = $_SERVER['DOCUMENT_ROOT']."/mayo/css/media.css";

$config = $_SERVER['DOCUMENT_ROOT']."/mayo/config/mayo-config.php";

$loginheader = $_SERVER['DOCUMENT_ROOT']."/mayo/mayo-admin/users/header.php";

$headerwtlogin = $_SERVER['DOCUMENT_ROOT']."/mayo/mayo-admin/header.php";

$jqueryminjs = $_SERVER['HTTP_HOST']."/mayo/jquery-validations/jquery.min.js";

$validateminjs = $_SERVER['HTTP_HOST']."/mayo/jquery-validations/jquery.validate.min.js";

?>
